// ── core/auto-levels.js ───────────────────────────────────────────────────────
// Safe Surfing Sentinel 1.0.0 — zero configuration: there is no slider and no per-site lock the
// user sets. A site's level is always ONE of: whitelisted (core/site-locks.js, LEVEL.ALLOW_ALL,
// user-controlled — the only thing the user ever touches), or computed HERE from static lists, or
// FIXED_LEVEL. Pure: no chrome.* calls, no state besides the frozen tables below.
//
// Precedence (data/constants.js AUTO_LEVEL_RULES, first match wins):
//   1. adult site (data/network-data.js HIGH_RISK_HOSTNAMES)                → LEVEL.HIGH
//   2. abused TLD (data/spam-tlds.js SPAM_TLDS, minus SPAM_TLD_EXCEPTIONS)  → LEVEL.SMART
//   3. risky domain (HostList: Kees1958 + HaGeZi Badware Hoster + DynDNS)   → LEVEL.SMART
//   else                                                                    → FIXED_LEVEL
//
// Public interface:
//   autoLevelOf(host) -> { level, status, source: AUTO_LEVEL_SOURCE.* | null }
//   isAutoElevated(host) -> boolean — adult OR abused TLD OR risky domain (i.e. autoLevelOf's source is not
//                          null — anything the system itself already flags) — owner, 2026-11-26: "whitelist
//                          it only for this browsing session" (first asked for abused TLD + risky domain,
//                          then confirmed yes to adult too). core/site-locks.js uses this to decide whether
//                          adding a site to the whitelist is permanent or session-only.
//   AUTO_STRICT_DOMAINS   — frozen array: every domain/TLD this module elevates to LEVEL.SMART
//                           (SPAM_TLDS as bare TLD strings + every HostList domain) — for
//                           core/policy.js ruleGroups(), one DNR group covers all of them.
//   AUTO_STRICT_EXCLUDE   — SPAM_TLD_EXCEPTIONS: legitimate sites on an abused TLD, excluded from
//                           that group only (never excluded from the adult or risky-domain hits).
//   AUTO_ADULT_DOMAINS    — HIGH_RISK_HOSTNAMES, for the LEVEL.HIGH group.
// ─────────────────────────────────────────────────────────────────────────────

import { LEVEL, FIXED_LEVEL, AUTO_LEVEL_SOURCE, AUTO_LEVEL_RULES, SITE_STATUS, STATUS_OF_LEVEL } from "../data/constants.js";
import { SPAM_TLDS, SPAM_TLD_EXCEPTIONS } from "../data/spam-tlds.js";
import { HIGH_RISK_HOSTNAMES } from "../data/network-data.js";
import { HostList } from "../lib/downloadsentinel/util/HostList.js";
import { HostListDefaultJson } from "../lib/downloadsentinel/util/HostList.default.js";
import { registeredDomain, isInDomainList } from "../util/domain.js";

// HostList has no "list every domain" export (only lookup()) — build the flat domain list once from
// its own default table, the same source HostList.lookup() reads (lib/downloadsentinel/util/HostList.default.js).
const HOST_LIST_DOMAINS = Object.freeze(Object.keys(JSON.parse(HostListDefaultJson)));
export const AUTO_STRICT_DOMAINS = Object.freeze([...SPAM_TLDS, ...HOST_LIST_DOMAINS]);
export const AUTO_STRICT_EXCLUDE = SPAM_TLD_EXCEPTIONS;
export const AUTO_ADULT_DOMAINS = HIGH_RISK_HOSTNAMES;

const RULE_BY_SOURCE = Object.freeze(Object.fromEntries(AUTO_LEVEL_RULES.map((r) => [r.source, r])));

function isAbusedTld(site) {
  return isInDomainList(site, SPAM_TLDS) && !isInDomainList(site, SPAM_TLD_EXCEPTIONS);
}
function isRiskyDomain(site) {
  return HostList.lookup(site) !== null;
}
function isAdultSite(site) {
  return HIGH_RISK_HOSTNAMES.includes(site);
}

// Any site autoLevelOf() would elevate on its own — adult, abused TLD, or risky domain (owner, 2026-11-26:
// confirmed to cover all three, not just the abused-TLD/risky-domain pair first asked about).
export function isAutoElevated(host) {
  const site = registeredDomain(host);
  return isAdultSite(site) || isAbusedTld(site) || isRiskyDomain(site);
}

// host → { level, status, source } — the automatic level BEFORE the whitelist override (core/policy.js
// applies the whitelist first and never calls this for a whitelisted host).
export function autoLevelOf(host) {
  const site = registeredDomain(host);
  if (isAdultSite(site)) { const r = RULE_BY_SOURCE[AUTO_LEVEL_SOURCE.ADULT]; return { level: r.level, status: r.status, source: r.source }; }
  if (isAbusedTld(site)) { const r = RULE_BY_SOURCE[AUTO_LEVEL_SOURCE.ABUSED_TLD]; return { level: r.level, status: r.status, source: r.source }; }
  if (isRiskyDomain(site)) { const r = RULE_BY_SOURCE[AUTO_LEVEL_SOURCE.RISKY_DOMAIN]; return { level: r.level, status: r.status, source: r.source }; }
  return { level: FIXED_LEVEL, status: STATUS_OF_LEVEL[FIXED_LEVEL], source: null };
}
